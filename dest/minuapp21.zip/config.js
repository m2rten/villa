var connectionString = process.env.DATABASE_URL || 'postgres://villa:Bylder2005@aa1a4z6bodxwhxz.cibjptxroqi3.us-east-1.rds.amazonaws.com:5432/villa';

module.exports = connectionString;